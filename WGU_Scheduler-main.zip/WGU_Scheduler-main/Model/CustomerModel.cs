﻿namespace Scheduler.Model
{
    internal class CustomerModel
    {
    }
}